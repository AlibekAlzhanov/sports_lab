import ch1 from '../images/Chicken-Sandwich.png'
import ch2 from '../images/Chicken-Deluxe.png'
import ch3 from '../images/Popeyes-box-L-spicy.png'
import ch4 from '../images/Chicken-meal.png'

function Chicken(){
    return(
        <div>
            <ul>
                <li><a href="#">Басты бет</a></li>
                <li><a href="#">Chicken</a></li>
                <li><a href="#">Сусындар</a></li>
            </ul>

            <h1>Chicken</h1>

            <table width="100%" border={1}>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Атауы</th>
                        <th>Суреті</th>
                        <th>Сипаттамасы</th>
                        <th>Бағасы</th>
                    </tr>
                    <tr>
                        <th>1</th>
                        <th>Chicken sandvich</th>
                        <th>
                            <img src={ch1} width={100} height={100} alt="" />
                        </th>
                        <th>
                            rdxgfchjb nkvhh hghfghejfh ghekjf gkeh
                        </th>
                        <th>
                            1000$
                        </th>
                    </tr>
                    <tr>
                        <th>2</th>
                        <th>Chicken sandvich deluxe</th>
                        <th>
                            <img src={ch2} width={100} alt="" />
                        </th>
                        <th>
                            ihvbefh vhefhv ehvbe lhfv e
                        </th>
                        <th>
                            1200$
                        </th>
                    </tr>
                    <tr>
                        <th>3</th>
                        <th>Chicken Box</th>
                        <th>
                            <img src={ch3} width={100} alt="" />
                        </th>
                        <th>
                            fhdvb fhvheg rfvgbr heb ef
                        </th>
                        <th>
                            1500$
                        </th>
                    </tr>
                    <tr>
                        <th>4</th>
                        <th>Cjicken Meal</th>
                        <th>
                            <img src={ch4} width={100} alt="" />
                        </th>
                        <th>
                            hg jhg jkfgg ghfghf 
                        </th>
                        <th>
                            1700$
                        </th>
                    </tr>
                </thead>
            </table>
        </div>
    )
}


export default Chicken;