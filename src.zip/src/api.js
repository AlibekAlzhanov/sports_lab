import axios from "axios";

export const api = axios.create({
  baseURL: "https://0b274e338de47f88.mokky.dev",
});
