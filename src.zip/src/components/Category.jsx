import React, { useEffect, useState } from "react";
import "./Home.css"; // можно оставить те же стили
import NewsCard from "./NewsCard";

function Category() {
  const [footballNews, setFootballNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchFootballNews = async () => {
      try {
        const response = await fetch("https://41b289b71f9c7ea3.mokky.dev/news");

        if (!response.ok) throw new Error("Ошибка при загрузке данных");

        const data = await response.json();

        const filtered = data.filter(
          (item) =>
            item.category &&
            item.category.toLowerCase().includes("футбол")
        );

        setFootballNews(filtered);
      } catch (err) {
        console.error(err);
        setError("Не удалось загрузить футбольные новости");
      } finally {
        setLoading(false);
      }
    };

    fetchFootballNews();
  }, []);

  if (loading) return <div className="home-page">Загрузка...</div>;
  if (error) return <div className="home-page">{error}</div>;

  return (
    <div className="home-page">
      <div className="phone-frame">
        {/* HEADER */}
        <header className="home-header">
          <div className="menu-icon">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </header>

   
        <div className="news-header">Футбол</div>

        <div className="news-container">
          {footballNews.length > 0 ? (
            footballNews.map((item) => (
              <NewsCard
                key={item.id}
                title={item.title}
                date={item.date}
                category={item.category}
              />
            ))
          ) : (
            <p style={{ textAlign: "center", marginTop: "20px" }}>
              Пока нет футбольных новостей 🏟️
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default Category;
