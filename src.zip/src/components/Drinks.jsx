import dr1 from '../images/11.png'
import dr2 from '../images/22.png'
import dr3 from '../images/33.png'
import dr4 from '../images/44.png'
import dr5 from '../images/55.png'

function Drinks(){
    return(
        <div>
            <ul>
                <li><a href="#">Басты бет</a></li>
                <li><a href="">Chicken</a></li>
                <li><a href="#">Сусындар</a></li>
            </ul>

            <h1>Drinks</h1>

            <table border={1}>
                <tr>
                    <th>
                        <table>
                            <tr>
                                <img src={dr1} width={250} alt="" />
                            </tr>
                            <tr>
                                Pico Orange
                            </tr>
                            <tr>
                                400$
                            </tr>
                        </table>
                    </th>
                    <th>
                        <table>
                            <tr>
                                <img src={dr2} width={250} alt="" />
                            </tr>
                            <tr>
                                Pico Apple
                            </tr>
                            <tr>
                                400$
                            </tr>
                        </table>
                    </th>
                    <th>
                        <table>
                            <tr>
                                <img src={dr3} width={250} alt="" />
                            </tr>
                            <tr>
                                Sprite
                            </tr>
                            <tr>
                                500$
                            </tr>
                        </table>
                    </th>
                    <th>
                        <table>
                            <tr>
                                <img src={dr4} width={250} alt="" />
                            </tr>
                            <tr>
                                Fants
                            </tr>
                            <tr>
                                500$
                            </tr>
                        </table>
                    </th>
                    <th>
                        <table>
                            <tr>
                                <img src={dr2} width={250} alt="" />
                            </tr>
                            <tr>
                                Cola
                            </tr>
                            <tr>
                                500$
                            </tr>
                        </table>
                    </th>
                </tr>
            </table>

            
        </div>
    )
}

export default Drinks;
