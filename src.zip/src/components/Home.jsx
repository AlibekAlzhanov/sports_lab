import React, { useEffect, useState } from "react";
import "./Home.css";
import NewsCard from "./NewsCard";

function Home() {
  const [newsList, setNewsList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
  
    const fetchNews = async () => {
      try {
        const response = await fetch("https://41b289b71f9c7ea3.mokky.dev/news");

        if (!response.ok) throw new Error("Ошибка при загрузке данных");

        const data = await response.json();
        setNewsList(data);
      } catch (err) {
        console.error(err);
        setError("Не удалось загрузить новости");
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
  }, []);

  if (loading) return <div className="home-page">Загрузка...</div>;
  if (error) return <div className="home-page">{error}</div>;

  return (
    <div className="home-page">
      <div className="phone-frame">
        <header className="home-header">
          <div className="menu-icon">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </header>

        <div className="news-header">Все новости</div>

        <div className="news-container">
          {newsList.map((news) => (
            <NewsCard
              key={news.id}
              title={news.title}
              date={news.date}
              category={news.category}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

export default Home;
