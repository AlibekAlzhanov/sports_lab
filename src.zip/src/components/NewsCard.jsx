import React from "react";

function NewsCard(props) {
  return (
    <div className="news-card">
      <p className="news-title">{props.title}</p>
      <p className="news-date">{props.date}</p>
      <p className="news-category">{props.category}</p>
    </div>
  );
}

export default NewsCard;
