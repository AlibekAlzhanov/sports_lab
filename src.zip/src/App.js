import Chicken from "./components/Chicken";
import Drinks from "./components/Drinks";
import Welcome from "./components/Welcome";
import Orders from "./components/Orders";
import Home from "./components/Home";
import Detail from "./components/Detail";
import Categories from "./components/Categories";
import Category from "./components/Category";

function App() {
  return (
    <div>
     <Home/>
    </div>
  );
}

export default App;

