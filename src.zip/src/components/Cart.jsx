// src/components/Cart.jsx
import React from "react";
import "./Cart.css";

function Cart({ cart, removeFromCart, goBack }) {
  return (
    <div className="cart-page">
      {/* Header */}
      <header className="header">
        <div className="logo">BAHANDI</div>

        <nav className="nav">
          <button className="cart" onClick={goBack}>
            Назад
          </button>
        </nav>
      </header>

      <main className="content">
        <h1 className="title">Корзина</h1>

        {cart.length === 0 ? (
          <p>Корзина пуста 🛒</p>
        ) : (
          <ul className="cart-list">
            {cart.map((item, i) => (
              <li key={i}>
                {item.name} — {item.price}
                <button
                  className="remove-btn"
                  onClick={() => removeFromCart(i)}
                >
                  Удалить
                </button>
              </li>
            ))}
          </ul>
        )}
      </main>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-left">
          <h2>BAHANDI</h2>
          <p>© 2024 ТОО "Баханди". Все права защищены.</p>
        </div>

        <div className="footer-right">
          <ul>
            <li>Компания</li>
            <li>Франшиза</li>
            <li>Вакансии</li>
            <li>Оферта</li>
            <li>Политика конфиденциальности</li>
            <li>Карта сайта</li>
          </ul>
        </div>
      </footer>
    </div>
  );
}

export default Cart;
