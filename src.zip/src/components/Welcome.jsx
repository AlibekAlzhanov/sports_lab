import logo from '../images/IMAGE3.webp'

function Welcome(){
    return(
        <div>
            <ul>
                <li><a href="#">Басты бет</a></li>
                <li><a href="Chiken.jsx">Chicken</a></li>
                <li><a href="#">Сусындар</a></li>
            </ul>

            <h1>Hot Chiken мейрамханалар желіне қош келдіңіз</h1>

            <img src={logo} width={500} alt="" />

            <p>Біздің мәзірмен сілтеме бойынша тқмен таныса аласыз </p>

            <ul>
                <li><a href="#">Chicken</a></li>
                <li><a href="#">Сусындар</a></li>
            </ul>
        </div>

        


    )
}

export default Welcome;