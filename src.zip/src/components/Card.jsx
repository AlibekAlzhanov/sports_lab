import React from "react";
import "./Card.css";

function Card({ name, price, image, onAdd }) {
  return (
    <div className="card">
      <div className="image-placeholder">
        {image && <img src={image} alt={name} />}
      </div>
      <div className="info">
        <div className="price">{price}</div>
        <div className="name">{name}</div>
        <button className="add-btn" onClick={onAdd}>
          В корзину
        </button>
      </div>
    </div>
  );
}

export default Card;
