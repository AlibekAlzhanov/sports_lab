import React from "react";
import "./Categories.css";

import img1 from "../images/image5.png";
import img2 from "../images/image31.png";
import img3 from "../images/image32.png";
import img4 from "../images/image4.png";
import img5 from "../images/image8.png";
import img6 from "../images/image9.png";
import img7 from "../images/image6.png";
import img8 from "../images/image7.png";

function Categories() {
  const items = [
    { img: img1, text: "Все новости" },
    { img: img2, text: "Футбол" },
    { img: img3, text: "Баскетбол" },
    { img: img4, text: "Регби" },
    { img: img5, text: "Хоккей" },
    { img: img6, text: "Киберспорт" },
    { img: img7, text: "Бокс" },
    { img: img8, text: "Mix Fight" },
  ];

  return (
    <div className="categories-page">
      <div className="phone-frame">
        <header className="home-header">
          <div className="menu-icon">
            <span></span>
            <span></span>
            <span></span>
          </div>
        </header>

        <div className="categories-bar">
          <span className="categories-text">Категории</span>
        </div>

        <div className="categories-grid">
          {items.map((item, index) => (
            <div key={index} className="category-card">
              <img src={item.img} alt={item.text} className="category-img" />
              <p className="category-label">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Categories;
