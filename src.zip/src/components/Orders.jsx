import React, { useState, useEffect } from "react";
import "./Orders.css";
import Card from "./Card";

function Orders() {
  const [drinks, setDrinks] = useState([]);
  const [cart, setCart] = useState([]);

  
  useEffect(() => {
    fetch("https://8d136bf4072a4892.mokky.dev/drinks")
      .then((res) => res.json())
      .then((data) => setDrinks(data))
      .catch((err) => console.error("Ошибка загрузки данных:", err));
  }, []);

  const addToCart = (item) => {
    setCart((prev) => [...prev, item]);
  };

  const removeFromCart = (index) => {
    setCart((prev) => prev.filter((_, i) => i !== index));
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div className="orders-page">
      {/* Header */}
      <header className="header">
        <div className="logo">BAHANDI</div>

        <nav className="nav">
          <a href="#">Бургеры</a>
          <a href="#">Напитки</a>
          <a href="#">Комбо</a>
          <a href="#" className="cart">
            Корзина: {totalPrice.toLocaleString("ru-RU")} ₸
          </a>
        </nav>
      </header>

      {/* Main */}
      <main className="content">
        <h1 className="title">Напитки</h1>

        <div className="grid">
          {drinks.map((drink) => (
            <Card
              key={drink.id}
              name={drink.name}
              price={`${drink.price.toLocaleString("ru-RU")} ₸`}
              image={drink.image}
              onAdd={() => addToCart(drink)}
            />
          ))}
        </div>

        {cart.length > 0 && (
          <div className="cart-list">
            <h2>🛒 Корзина</h2>
            <ul>
              {cart.map((item, i) => (
                <li key={i}>
                  {item.name} — {item.price.toLocaleString("ru-RU")} ₸
                  <button
                    className="remove-btn"
                    onClick={() => removeFromCart(i)}
                  >
                    Удалить
                  </button>
                </li>
              ))}
            </ul>

            <h3>
              💰 Итого: <span>{totalPrice.toLocaleString("ru-RU")} ₸</span>
            </h3>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-left">
          <h2>BAHANDI</h2>
          <p>© 2024 ТОО "Баханди". Все права защищены.</p>
        </div>

        <div className="footer-right">
          <ul>
            <li>Компания</li>
            <li>Франшиза</li>
            <li>Вакансии</li>
            <li>Оферта</li>
            <li>Политика конфиденциальности</li>
            <li>Карта сайта</li>
          </ul>
        </div>
      </footer>
    </div>
  );
}

export default Orders;
