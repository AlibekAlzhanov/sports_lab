function CategoryCard({ image, name }) {
  return (
    <div className="card">
      <div className="logo">
        <img src={image} width="47.81px" height="48px" alt={name} />
      </div>
      <div className="logo-p">{name}</div>
    </div>
  );
}

export default CategoryCard;